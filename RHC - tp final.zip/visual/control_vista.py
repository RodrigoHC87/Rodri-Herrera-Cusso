
from random import choice

class ApartadoVisual:

    def limpiar_entradas(self, nombre, edad, email, provincia, voto):
        nombre.set("")
        edad.set("")
        email.set("")
        provincia.set("")
        voto.set("")


    def  insertar_encuesta_modificar(self, valores, nombre, edad, email, prov, int_voto ):
        nombre.insert(0, valores[0])
        edad.insert(0, valores[1])
        email.insert(0, valores[2])
        prov.configure(state="normal")
        prov.insert(0, valores[3])
        prov.configure(state="readonly")
        int_voto.configure(state="normal")
        int_voto.insert(0, valores[4])
        int_voto.configure(state="readonly")
        nombre.focus()


    def ord_aleatorio_candidatos(self, opciones_vot):
        candidatos = ["Voto en BLanco", "La libertad no avanza", "Por unión la patria", "La SINiestra", "Juntos sin el cambio"]
        values = candidatos
        l0= ""
        l1= choice(values)
        values.remove(l1)
        l2= choice(values)
        values.remove(l2)
        l3= choice(values)
        values.remove(l3)
        l4= choice(values)
        values.remove(l4)
        l5= choice(values)
        values = [l0, l1, l2, l3, l4, l5]
        opciones_vot["values"] = (values)


    def help_mail(self, edad, opcion):
        edad.delete(0, "end")
        if opcion == 2:
            edad.configure(disabledforeground="red")
            edad.insert(0,"ej: pepe99@yahoo.com")
            edad.configure(state="disabled")
            edad.bind("<Button-1>", lambda limpiar:(edad.configure(fg="black", state="normal"), edad.delete(0, "end")))
        edad.focus_set()


    def help_edad(self, email, opcion):
        email.delete(0, "end")
        if opcion == 4:
            email.configure(disabledforeground="red")
            email.insert(0,"ej: 26")
            email.configure(state="disabled")
            email.bind("<Button-1>", lambda despejar:(email.configure(fg="black", state="normal"), email.delete(0, "end")))
        email.focus_set()


    def help_campos_vacios(self, opcion, nombre, edad, email, prov, int_voto):
        if opcion == 1:
            nombre.focus_set()
        elif opcion == 2:
            edad.focus_set()
        elif opcion == 3:
            email.focus_set()
        elif opcion == 4:
            prov.focus_set()
        else:
            int_voto.focus_set()
