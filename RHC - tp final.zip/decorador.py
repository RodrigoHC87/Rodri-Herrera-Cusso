from peewee import *
from datetime import datetime

ruta_db_acc = "bases_de_datos/db_reg_deco.db"
db_acc = SqliteDatabase(ruta_db_acc)

#db_acc = SqliteDatabase("db_reg_deco.db")

class BaseModel(Model):
    class Meta:
        database = db_acc

class Modificaciones(BaseModel):
    id = AutoField()
    accion = CharField()
    fecha = CharField()
    hora = CharField()

db_acc.connect()
db_acc.create_tables([Modificaciones])


def tipo_de_entrada(name):
    def wrapper (funcion):
        def wrapper_2(*args, **kwargs):
            resultado_fun = funcion(*args, **kwargs)

            datos_registro = [name, datetime.today().strftime("%d/%m/%y"), datetime.now().strftime("%H:%M:%S")]

            if resultado_fun == 0 or resultado_fun == "ok":
                print("Acción del decorador.-")
                print(f"La acción '{name}' fue registrada en la fecha - {datos_registro[1]} a la hora: {datos_registro[2]}")
                print("---------------------------------------------------------------------\n")
                mod1 = Modificaciones()
                mod1.accion = name
                mod1.fecha = datos_registro[1]
                mod1.hora = datos_registro[2]
                mod1.save()
            return resultado_fun
        return wrapper_2
    return wrapper